import axios from "axios";
import https from "https"
export const handler = async (event) => {
 const postData = {
    startTime: "10:00"
  };
  const httpsAgent = new https.Agent({ rejectUnauthorized: false });

  console.log("End contest:",postData);
  const url = "https://api.marketplay.in/start-contest";
  try{
   const res = await axios.post(url,postData,{httpsAgent}); 
  }catch (e){
   console.log('Error:',e)
  }
  
 
 return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ message: 'Success' })
    };
};


